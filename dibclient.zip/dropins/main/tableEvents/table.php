<?php 

/* 
    This class can be extended by the specific table classes.
    Add any general code here that the table classes use.
*/

class table {
    
}