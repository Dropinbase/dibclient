<?php 

class DIB {
    public static $DATABASES = array();
    public static $ACTION = array();
    public static $USER = ['unique_id'=>null]; // required for DCurl
    public static $RUNTIMEPATH = '';
    public static $SYSTEMPATH = '';
}
