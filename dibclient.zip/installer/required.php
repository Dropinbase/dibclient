<?php 

/* 
 * Copyright (C) Dropinbase - All Rights Reserved
 * This code, along with all other code under the root /dropinbase folder, is provided "As Is" and is proprietary and confidential
 * Unauthorized copying or use, of this or any related file, is strictly prohibited
 * Please see the License Agreement at www.dropinbase.com/license for more info
*/
echo '{
     "success" : false,
     "errors" : [
        {
            "name": "Database Connection",
            "ready": true,
            "notes": "Could not connect"
        },
        {
            "name": "Modules missing",
            "ready": true,
            "notes": ""
        }
    ]}';
?>