<?php

require_once './configs/SecurityHeadersFiles.php';

$DIR = __DIR__;
include_once("./dropinbase/files.php");