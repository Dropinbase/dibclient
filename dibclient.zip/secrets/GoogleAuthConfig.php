<?php 

class GoogleAuthConfig { 
    const SALT = "***"; // provide a random string
}