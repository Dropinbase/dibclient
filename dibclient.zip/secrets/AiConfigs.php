<?php 

// openai.com API key
$OPENAI_APIKEY = '';


