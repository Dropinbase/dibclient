<?php 

// Define API authentication tokens for clients accessing the Dropinbase framework
// These tokens are verified in SiteController.php when /dropins/dibAuthenticate/SiteController/login/?api=1 requests are made
// Update tokens periodically.

$this->apiTokens = array(
    'username1' => 'Tg1Ja2_yKwQIQfi02iJ0vrlL',
);